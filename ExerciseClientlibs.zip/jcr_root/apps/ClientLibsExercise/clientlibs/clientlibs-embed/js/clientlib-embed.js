
console.log("CLIENTLIBS-EMBED loaded");